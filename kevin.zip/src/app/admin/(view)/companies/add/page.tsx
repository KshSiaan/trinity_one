import { CompanyInfoCard } from "./company-info";

export default function Page() {
  return (
    <section className="space-y-6">
      <CompanyInfoCard />
    </section>
  );
}
