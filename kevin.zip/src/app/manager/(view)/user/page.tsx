import React from "react";
import UsersTable from "./user-table";

export default function Page() {
  return (
    <section>
      <UsersTable />
    </section>
  );
}
