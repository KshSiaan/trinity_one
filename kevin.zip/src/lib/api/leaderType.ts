export interface LeaderType {
    employee_id : number,
    name: string,
    role: string,
    total_goals: number,
    completed: number,
    engagement: number,
    roi_impact: number
}